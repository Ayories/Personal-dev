# -*- coding: utf-8 -*-
"""
Created on Sun Feb  1 22:22:11 2026

@author: sanus
"""

Display 'Charity tin total calculator program'
skip a line
Request user to input the number of 1p coins
Request user to input the number of 2p coins
Request user to input the number of 5p coins
Request user to input the number of 10p coins
Request user to input the number of 20p coins
Request user to input the number of 50p coins
Request user to input the number of £1 coins
Request user to input the number of £2 coins  
Calculate total value/amount based on the number of coins listed
skip a line
Display message 'The total amount in tin is £' + str(total_amount / 100)
