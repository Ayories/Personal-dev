import math
radius = float(input('Enter the radius: '))
area = math.pi * radius ** 2
print(area ," is the area of the circle with radius", radius)